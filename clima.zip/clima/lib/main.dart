import 'dart:convert';

import 'package:dotenv/dotenv.dart';
import 'package:http/http.dart' as http;

void main(List<String> arguments) async {
  var env= DotEnv(includePlatformEnvironment: true)..load();
  var apiKey=env['API_KEY'];

  if (apiKey==null || apiKey.isEmpty) {
    print('API_KEY no esta configurada en el archivo env');
    return;
  }

  String? city ="La Ceiba";
  if (city == null || city.isEmpty) {
    print('El nombre de la ciudad no puede estar vacio');
    return;
  }

  await fetchWeather(city, apiKey);
}


Future<void> fetchWeather(String city, String apiKey) async{
  final url = Uri.parse(
          'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric');
  final response = await http.get(url);

  if (response.statusCode == 200) {
    final data= json.decode(response.body);

    print('Clima en: $city:');
    print('Descripcion: ${data['weather'][0]['descripcion']}');
    print('Temperatura: ${data['main']['temp']}°C');
    print('Humedad: ${data['main']['humidity']}%');
    print('Viento: ${data['wind']['speed']}m/s');
  }else{
    print('Error al obtener el clima: ${response.reasonPhrase}');
  }
}


